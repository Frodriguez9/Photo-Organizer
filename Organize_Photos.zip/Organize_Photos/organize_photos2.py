# TO DO: add Path so that the program runs from any place
# and not only on 'organize_photos'

import os
import sys

if len(sys.argv) < 2:
    print('\nUsage: python3 organize_photos2.py [Directory]'
          '- copy phrase text\n')
    sys.exit()

directory_to_be_manipulated = sys.argv[1]


def extract_place(filename):
    return filename.split("_")[1]


def make_place_directory():
    for file in originals:
        try:
            os.mkdir(extract_place(file))
            places.append(extract_place(file))
        except FileExistsError:
            continue


def move_files():
    for place in places:
        for file in originals:
            if extract_place(file) == place:
                os.rename(file, os.path.join(place, file))
            else:
                continue


def organize_photos(directory):
    os.chdir(directory)
    global originals
    global places
    places = []
    originals = os.listdir()
    make_place_directory()
    move_files()


if __name__ == '__main__':
    organize_photos(directory_to_be_manipulated)
